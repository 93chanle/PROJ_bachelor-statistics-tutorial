
# for Schleife
for (i in 1:10){print(i)}
for (i in 5:1){print(i)}
for (i in c(1,3,4,10)){print(i)}

# while Schleife
n=1
while(n<11){
print(n)
n<-n+1
}

# repeat Schleife
n=1
repeat{
print(n)
n<-n+1
if(n>10) break
}


# Beispiele
z <- 1:10
for (i in 1:10){
z[i] <- z[i]+1
}

z <- 1:10
z <- z+1

phrase<-"the quick brown fox jumps over the lazy dog"
q<-character(20)
for (i in 1:20) q[i]<- substr(phrase,1,i)
q

# mehrfaches Zufallssampling plotten
par(mfrow=c(2,2))
for (i in 1:4){
daten <- rnorm(50)
plot(daten,main=paste("Stichprobe",i))
}



#loop with data

utils::data(npk, package="MASS")
attach(npk)
result<-matrix(ncol=2,nrow=3)
boxplot(yield~N)
boxplot(yield~P)
boxplot(yield~K)

for (i in 2:4){
print(i)
model<-aov(yield~npk[,i])
result[i-1,2]<-summary(model)[[1]]$P[1]
result[i-1,1]<-colnames(npk)[i]
}




#climate loop

hvw1<-read.table("climate.txt",header=T)
attach(hvw1)
library(mgcv)
library(climatol)



        
for (i in 1:dim(hvw1)[1]){
Min.t.<-as.numeric(hvw1[i,6:17])
Max.t.<-as.numeric(hvw1[i,18:29])
Prec<-as.numeric(hvw1[i,30:41])
station<-data.frame(Prec,Min.t.,Max.t.,Ab.m.t.=Min.t.)
tstat<-as.data.frame(t(station))
names(tstat)<-c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
row.names(tstat)<-names(station)
diagwl(tstat,est=paste(hvw1$POINTNO[i],"; LON:",hvw1$LON_EX[i],"; LAT:",hvw1$LAT_EX[i]),alt=hvw1$ALT_EX[i])
savePlot(filename=paste(hvw1$POINTNO[i]),type="jpg")
graphics.off()
                          }




